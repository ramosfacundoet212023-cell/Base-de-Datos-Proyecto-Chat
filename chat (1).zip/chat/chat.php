<?php
include 'conexion.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['rol'] !== 'estudiante') {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['aula_id'])) {
    header("Location: aulas.php");
    exit();
}

$id_aula = $_SESSION['aula_id'];

// Procesar envío de mensaje dinámicamente
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['mensaje'])) {
    $mensaje = trim($_POST['mensaje']);
    $id_us = $_SESSION['user_id'];

    if (!empty($mensaje)) {
        // ID_AGBD se establece como NULL por defecto para chats iniciados por estudiantes
        $stmt = $conn->prepare("INSERT INTO Chats (ID_Us, ID_Aula, Mensajes) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $id_us, $id_aula, $mensaje);
        $stmt->execute();
    }
}

// Obtener los mensajes pertenecientes únicamente al aula activa
$query = "SELECT c.Mensajes, c.ID_Us, u.Nombre_y_Apellido 
          FROM Chats c 
          JOIN Usuario u ON c.ID_Us = u.ID_Us 
          WHERE c.ID_Aula = ? 
          ORDER BY c.ID_Chat ASC";

$stmt_get = $conn->prepare($query);
$stmt_get->bind_param("i", $id_aula);
$stmt_get->execute();
$result = $stmt_get->get_result();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Aula Virtual - Chat Anónimo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body { background-color: #f0f2f5; }
        .chat-room { height: 60vh; overflow-y: auto; background: white; border-radius: 8px; padding: 15px; }
        .msg-box { margin-bottom: 12px; }
        .msg-anon { background-color: #e9ecef; border-radius: 15px; padding: 8px 14px; display: inline-block; max-width: 75%; }
        .msg-me { background-color: #0d6efd; color: white; border-radius: 15px; padding: 8px 14px; display: inline-block; max-width: 75%; }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h4 class="fw-bold mb-0">
                    <i class="bi bi-door-open-fill text-primary"></i> 
                    Aula: <?php echo htmlspecialchars($_SESSION['aula_nombre'] ?? 'General'); ?>
                </h4>
                <span class="badge bg-success">
                    Registrado como: <?php echo htmlspecialchars($_SESSION['nombre']); ?> (Tu identidad es Anónima para tus pares)
                </span>
            </div>
            <div>
                <a href="aulas.php" class="btn btn-outline-secondary btn-sm me-2">
                    <i class="bi bi-arrow-left"></i> Cambiar de Aula
                </a>
                <a href="login.php" class="btn btn-outline-danger btn-sm">Cerrar Sesión</a>
            </div>
        </div>

        <div class="row">
            <div class="col-md-3 mb-3">
                <div class="card bg-light border-0 shadow-sm">
                    <div class="card-body">
                        <h6 class="fw-bold"><i class="bi bi-shield-check"></i> Código de Conducta</h6>
                        <p class="text-muted small">Este espacio promueve la participación inclusiva y el debate respetuoso. Se sanciona el cyberbullying.</p>
                    </div>
                </div>
            </div>

            <div class="col-md-9">
                <div class="chat-room shadow-sm border mb-3 p-3">
                    <div class="messages">
                        <?php if ($result && $result->num_rows > 0): ?>
                            <?php while($row = $result->fetch_assoc()): ?>
                                <?php $es_propio = ($row['ID_Us'] == $_SESSION['user_id']); ?>
                                <div class="msg-box <?php echo $es_propio ? 'text-end' : 'text-start'; ?>">
                                    <span class="d-block small text-muted mb-1">
                                        <?php echo $es_propio ? 'Vos (Anónimo)' : 'Estudiante Anónimo'; ?>
                                    </span>
                                    <div class="<?php echo $es_propio ? 'msg-me' : 'msg-anon'; ?>">
                                        <?php echo htmlspecialchars($row['Mensajes']); ?>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <p class="text-center text-muted my-4">Aún no hay mensajes en esta aula. ¡Sé el primero en preguntar!</p>
                        <?php endif; ?>
                    </div>
                </div>

                <form action="chat.php" method="POST" class="input-group">
                    <input type="text" name="mensaje" class="form-control" placeholder="Escribí una duda o comentario..." required>
                    <button class="btn btn-primary" type="submit"><i class="bi bi-send"></i> Enviar</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>